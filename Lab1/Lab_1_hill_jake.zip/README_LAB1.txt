CSE 4252 C++ Programming
Lab1
Jake Hill

File Description:
	- calculator.cpp: src code for calculator exercise specified in the lab1 description
	- commands.txt: The Linux commands used to complete exercise 1
	- lab1_exerc2_rec.txt: The output of using the script service on the OSU std-Linux
	  					   server when compiling calculator.cpp using g++ compiler

Caclulator App Usage:

1) compile calculator.cpp for the console using:
	- > g++ -o calculator calculator.cpp
2) Run the calculator executable through console
3) First you will be promted with operator options
	- Type the specified operator and use return to commit answer
4) Second you will be prompted for two operands
	- This program accepts floating point numbers
5) After commiting both numbers you will recieve the result of you inquiry
6) You will then have the option to either query for another calulation or
   you may specify 'q' as your operator to exit the program.